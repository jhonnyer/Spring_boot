import logo from './logo.svg';
import './App.css';
import { Col, Container, Row } from 'reactstrap';
import ListaCatalogo from './Lista_catalogo';
import { useEffect, useState } from 'react';
import axios from 'axios';
import FormularioCatalogo from './FormularioCatalogo';
import Banner from './Banner';

function App() {

  // Usar AXIOS y definir la lista de catalogo 
  // Al inicio del valor del catalogo va a ser una lista en blanco 
  const [catalogo, setCatalogo]=useState([]);
  // Para editar 
  const [catalogoid, setCatalogoid]=useState();
  console.debug(catalogo)
  console.debug('prueba')

  // cargamos el catalogo desde el API 
  const cargarCatalogo=()=>{
    axios.get('http://localhost:8080/catalogo/api/v1/all')
      .then(({data})=> setCatalogo(data));
  }

  useEffect(cargarCatalogo,[]);

  // Funcion para crear un registro en la API 
  // const onSubmit = (values) =>{
  //   axios.post('http://localhost:8080/catalogo/api/v1/save', values)
  //   .then(()=> cargarCatalogo());
  // }

  // Funcion para crear y actualizar un registro en la API 
  const onSubmit = (values) =>{
    if (catalogoid){
      // Si el registro existe, se actualiza sino se crea en el else 
      axios.put(`http://localhost:8080/catalogo/api/v1/update/${catalogoid.id}`, values)
        .then(()=> {
          setCatalogoid(); //limpiamos los datos del catalogo que estaban en edicion 
          cargarCatalogo();
      });
    }else{
      axios.post('http://localhost:8080/catalogo/api/v1/save', values)
        .then(()=> cargarCatalogo());
    }
  }

  // Funcion para eliminar un registro 
  const eliminarRegistro = (catalogo) => {
    console.log=('{catalogo.id}}')
    axios.get(`http://localhost:8080/catalogo/api/v1/delete/${catalogo.id}`)
    .then(()=> cargarCatalogo());
  }

  // Funcion para actualizar o editar un registro 
  
  return (
    <>
      <Container>
        <Banner />
        <Row className="mt-5">
          <Col md={8}>
            <ListaCatalogo catalogo={catalogo} onDelete={eliminarRegistro} onEdit={(catalogoid)=>setCatalogoid(catalogoid)}/>
          </Col>
          <Col md={4}>
              <FormularioCatalogo onSubmit={onSubmit} catalogoid={catalogoid}/>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default App;
