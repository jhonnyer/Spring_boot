import React from "react";

import img from './img/catalogo.png';
const Banner = () => {
    return (
        <div className="rounded shadown p-5 mt-5 d-flex">
            <img src={img} alt="" width="250"></img>
            <div>
                <h3 className="text-primary">Bienvenido a nuestro Catalogo de productos virtuales</h3>
                <h5 className="text-secondary">
                    Con está aplicación podrás consultar, crear, actualizar y eliminar registros de un catalogo de productos virtuales
                </h5>
                <hr />
                <p className="text-muted">Esta aplicación fue desarrollada con Spring Boot, React y MongoDB por Jhonnyer Fernando Galindez Zemanate.</p>
            </div>
        </div>
    );
}

export default Banner;