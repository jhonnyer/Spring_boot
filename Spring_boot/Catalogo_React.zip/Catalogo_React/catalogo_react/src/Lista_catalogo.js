import { faEdit, faTrash, faClock, faCheckCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from "react";

// ListaCatalogo recibe como parametros la lista de catalogo 
const ListaCatalogo = ({catalogo, onDelete, onEdit}) => {
    // const disponibilidad=[];
    // for (var i=0; i<catalogo.length;i++){
    //     // console.log(catalogo[i].disponibilidad);
    //     disponibilidad.push(catalogo[i].disponibilidad);
    // }
    // console.log(disponibilidad)
    return (
        <>
            <h3 className="mb-3">Catalogo Virtual</h3>
            {
                catalogo.map(catalogo =>
                    <div className="mb-4 border rounded p-3" key={catalogo.id}>
                        {/* <div className="d-flex justify-content-between mb-1 text-center"> */}
                        <div className="col-md-4">
                            <div className="Row">
                                <div className="Heading bg-dark text-white justify-content-between align-items-center">
                                    <div className="Cell">Nombre</div>
                                    <div className="Cell">Categoria</div>
                                    <div className="Cell">Descripción</div>
                                    <div className="Cell">Precio</div>
                                    <div className="Cell">Disponibilidad</div>
                                    <div className="Cell">Cantidad</div>
                                    <div className="Cell">Editar</div>
                                    <div className="Cell">Eliminar</div>
                                </div>
                                <div className="Row">
                                    <div className="Cell fw-bold" >{catalogo.nombre}</div>
                                    <div className="Cell">{catalogo.categoria}</div>
                                    <div className="Cell">{catalogo.descripcion}</div>
                                    <div className="Cell">{catalogo.precio}</div>
                                    <div className="Cell">
                                        {
                                            catalogo.disponibilidad ?   
                                            <div className="text-sucess small">
                                                <FontAwesomeIcon icon={faCheckCircle}/>{" "}
                                                Disponible
                                            </div>
                                            : 
                                            <div className="text-secondary small">
                                                <FontAwesomeIcon icon={faClock}/>{" "}
                                                No Disponible
                                            </div>
                                        }
                                    </div>
                                    <div className="Cell">{catalogo.cantidad}</div>
                                    <div className="Cell"><FontAwesomeIcon icon={faEdit} className="cursor-pointer" onClick={()=>onEdit(catalogo)}/></div>
                                    <div className="Cell"><FontAwesomeIcon icon={faTrash} className="cursor-pointer ms-2" onClick={()=>onDelete(catalogo)}/></div>
                                </div>
                            </div>
                        </div>
                            
                        {/* <div className="d-flex justify-content-between mb-1">
                            <div className="fw-bold">{catalogo.nombre}</div>
                            <div>
                                <FontAwesomeIcon icon={faEdit} className="cursor-pointer" onClick={()=>onEdit(catalogo)}/>
                                <FontAwesomeIcon icon={faTrash} className="cursor-pointer ms-2" onClick={()=>onDelete(catalogo)}/>
                            </div>
                        </div> */}
                        {/* <div>
                            {
                                catalogo.disponibilidad ?   
                                <div className="text-sucess small">
                                    <FontAwesomeIcon icon={faCheckCircle}/>{" "}
                                    Disponible
                                </div>
                                : 
                                <div className="text-secondary small">
                                    <FontAwesomeIcon icon={faClock}/>{" "}
                                    No Disponible
                                </div>
                            }
                        </div> */}
                    </div>
                )
            }
        </>
    );
}

export default ListaCatalogo;