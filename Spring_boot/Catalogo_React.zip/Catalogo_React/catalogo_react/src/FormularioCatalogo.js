import React, { useRef } from 'react';
import { AvForm, AvField, AvInput, AvGroup } from 'availity-reactstrap-validation';
import { Label, Button } from 'reactstrap';

const FormularioCatalogo = ({catalogoid, onSubmit }) => {

    let form = useRef(); //Resetear los campos llenados por el usuario
    const _onSubmit= (values)=>{
        onSubmit(values);
        form.reset();
    }

    return (
        <>
            <h3 className="mb-3">{catalogoid ? 'Editar' : 'Nuevo'} Articulo</h3>
            {/* Configuracion para enviar datos del formulario cuando se presiona el boton onSubmit  */}
            <AvForm ref={c=>(form=c)} onValidSubmit={(_,values)=> _onSubmit(values)}>
                <AvGroup className="mb-3">
                    <AvField name="categoria" label="Categoria" required value={catalogoid ? catalogoid.categoria: ''}/>
                </AvGroup>

                <AvGroup className="mb-3">
                    <AvField name="nombre" label="Nombre" required value={catalogoid ? catalogoid.nombre: ''}/>
                </AvGroup>

                <AvGroup className="mb-3">
                    <AvField name="descripcion" label="Descripción" required value={catalogoid ? catalogoid.descripcion: ''}/>
                </AvGroup>

                <AvGroup className="mb-3">
                    <AvField type="number" name="precio" label="Precio" required value={catalogoid ? catalogoid.precio: ''}/>
                </AvGroup>

                <AvGroup className="mb-3">
                    <AvField type="number" name="cantidad" label="Cantidad" required value={catalogoid ? catalogoid.cantidad: ''}/>
                </AvGroup>

                {/* <AvGroup className="mb-3">
                    <AvField type="file" name="producto" label="Imagén del Producto" required/>
                </AvGroup> */}

                <AvGroup check className="mb-3">
                    {/* <AvInput type="checkbox" name="disponibilidad" trueValue="si" falseValue="no"/> */}
                    <AvInput type="checkbox" name="disponibilidad" checked={catalogoid ? catalogoid.disponibilidad: false}/>
                    <Label check for="disponibilidad">Disponibilidad</Label>
                </AvGroup>

                <div className="text-end">
                    <Button color="primary">Guardar</Button>
                </div>
                
            </AvForm>
        </>
    )
}

export default FormularioCatalogo;